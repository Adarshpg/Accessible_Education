const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const path = require('path');
const multer = require('multer');
const fs = require('fs');
const PDF = require('../models/pdf');

// Mock user data - Replace with database
let users = [];

// Mock educational content
const educationalContent = {
    mathematics: {
        notes: [
            {
                id: 1,
                title: "Introduction to Algebra",
                content: "Algebra is the study of mathematical symbols and the rules for manipulating these symbols.",
                audioUrl: "/materials/math/algebra_intro.mp3",
                signLanguageUrl: "/materials/math/algebra_intro_sign.mp4",
                transcription: "Welcome to Algebra! Today we'll learn about mathematical symbols...",
                pdfUrl: '/pdfs/mathematics/algebra-intro.pdf',
                pdfTitle: 'Complete Algebra Guide'
            },
            {
                id: 2,
                title: "Basic Geometry",
                content: "Geometry is the study of shapes, sizes, and positions of things.",
                audioUrl: "/materials/math/geometry_basics.mp3",
                signLanguageUrl: "/materials/math/geometry_basics_sign.mp4",
                transcription: "In this lesson, we'll explore the fascinating world of geometry...",
                pdfUrl: '/pdfs/mathematics/geometry-basics.pdf',
                pdfTitle: 'Geometry Concepts & Practice'
            }
        ],
        speeches: [
            {
                id: 1,
                title: "Why Mathematics Matters",
                speaker: "Dr. Sarah Johnson",
                audioUrl: "/materials/math/why_math_matters.mp3",
                transcript: "Mathematics is not just about numbers, it's about understanding patterns...",
                signLanguageUrl: "/materials/math/math_matters_sign.mp4",
                duration: "15:00"
            }
        ]
    },
    science: {
        notes: [
            {
                id: 1,
                title: "Introduction to Physics",
                content: "Physics is the natural science that studies matter, motion, energy, and force.",
                audioUrl: "/materials/science/physics_intro.mp3",
                signLanguageUrl: "/materials/science/physics_intro_sign.mp4",
                transcription: "Welcome to Physics! Today we'll explore the fundamental laws..."
            },
            {
                id: 2,
                title: "Basic Chemistry",
                content: "Chemistry is the study of matter and the changes it undergoes.",
                audioUrl: "/materials/science/chemistry_basics.mp3",
                signLanguageUrl: "/materials/science/chemistry_basics_sign.mp4",
                transcription: "In this chemistry lesson, we'll learn about atoms and molecules..."
            }
        ],
        speeches: [
            {
                id: 1,
                title: "The Future of Science",
                speaker: "Prof. Michael Chen",
                audioUrl: "/materials/science/future_of_science.mp3",
                transcript: "Science is evolving rapidly, and new discoveries are being made every day...",
                signLanguageUrl: "/materials/science/science_future_sign.mp4",
                duration: "20:00"
            }
        ]
    },
    languages: {
        notes: [
            {
                id: 1,
                title: "English Grammar Basics",
                content: "Grammar is the system and structure of a language.",
                audioUrl: "/materials/languages/english_grammar.mp3",
                signLanguageUrl: "/materials/languages/english_grammar_sign.mp4",
                transcription: "Today we'll learn about basic English grammar rules..."
            }
        ],
        speeches: [
            {
                id: 1,
                title: "The Power of Communication",
                speaker: "Dr. Emma Wilson",
                audioUrl: "/materials/languages/power_of_communication.mp3",
                transcript: "Language is the key to understanding different cultures and perspectives...",
                signLanguageUrl: "/materials/languages/communication_sign.mp4",
                duration: "18:00"
            }
        ]
    }
};

// Configure multer for PDF uploads
const storage = multer.diskStorage({
    destination: function(req, file, cb) {
        const dir = path.join(__dirname, '../../uploads');
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }
        cb(null, dir);
    },
    filename: function(req, file, cb) {
        cb(null, Date.now() + '-' + file.originalname);
    }
});

const upload = multer({ 
    storage: storage,
    fileFilter: (req, file, cb) => {
        if (file.mimetype === 'application/pdf') {
            cb(null, true);
        } else {
            cb(new Error('Only PDF files are allowed!'), false);
        }
    }
});

// Store uploaded PDFs information with enhanced metadata
let pdfs = {
    mathematics: [],
    science: [],
    english: [],
    history: []
};

// Quiz Management
let quizzes = {
    mathematics: [],
    science: [],
    english: [],
    history: []
};

// Create a new quiz
router.post('/quiz/:subject', (req, res) => {
    try {
        const { subject } = req.params;
        const { title, questions, timeLimit } = req.body;

        const quiz = {
            id: Date.now(),
            title,
            questions,
            timeLimit,
            createdAt: new Date().toISOString(),
            attempts: []
        };

        quizzes[subject].push(quiz);
        res.json({ message: 'Quiz created successfully', quiz });
    } catch (error) {
        res.status(500).json({ error: 'Error creating quiz' });
    }
});

// Get quizzes for a subject
router.get('/quiz/:subject', (req, res) => {
    const { subject } = req.params;
    res.json(quizzes[subject] || []);
});

// Submit quiz attempt
router.post('/quiz/:subject/:quizId/attempt', (req, res) => {
    try {
        const { subject, quizId } = req.params;
        const { answers, timeTaken, userId } = req.body;

        const quiz = quizzes[subject].find(q => q.id === parseInt(quizId));
        if (!quiz) {
            return res.status(404).json({ error: 'Quiz not found' });
        }

        // Calculate score
        let score = 0;
        quiz.questions.forEach((question, index) => {
            if (answers[index] === question.correctAnswer) {
                score++;
            }
        });

        const attempt = {
            userId,
            score,
            timeTaken,
            submittedAt: new Date().toISOString()
        };

        quiz.attempts.push(attempt);
        res.json({ message: 'Quiz submitted successfully', score, totalQuestions: quiz.questions.length });
    } catch (error) {
        res.status(500).json({ error: 'Error submitting quiz' });
    }
});

// Discussion Forum
let discussions = {
    mathematics: [],
    science: [],
    english: [],
    history: []
};

// Create a new discussion
router.post('/discussion/:subject', (req, res) => {
    try {
        const { subject } = req.params;
        const { title, content, userId, userName } = req.body;

        const discussion = {
            id: Date.now(),
            title,
            content,
            userId,
            userName,
            createdAt: new Date().toISOString(),
            replies: [],
            likes: 0
        };

        discussions[subject].push(discussion);
        res.json({ message: 'Discussion created successfully', discussion });
    } catch (error) {
        res.status(500).json({ error: 'Error creating discussion' });
    }
});

// Get discussions for a subject
router.get('/discussion/:subject', (req, res) => {
    const { subject } = req.params;
    res.json(discussions[subject] || []);
});

// Add reply to discussion
router.post('/discussion/:subject/:discussionId/reply', (req, res) => {
    try {
        const { subject, discussionId } = req.params;
        const { content, userId, userName } = req.body;

        const discussion = discussions[subject].find(d => d.id === parseInt(discussionId));
        if (!discussion) {
            return res.status(404).json({ error: 'Discussion not found' });
        }

        const reply = {
            id: Date.now(),
            content,
            userId,
            userName,
            createdAt: new Date().toISOString(),
            likes: 0
        };

        discussion.replies.push(reply);
        res.json({ message: 'Reply added successfully', reply });
    } catch (error) {
        res.status(500).json({ error: 'Error adding reply' });
    }
});

// Progress Tracking
let userProgress = {};

// Update user progress
router.post('/progress/:userId', (req, res) => {
    try {
        const { userId } = req.params;
        const { subject, activity, score } = req.body;

        if (!userProgress[userId]) {
            userProgress[userId] = {};
        }
        if (!userProgress[userId][subject]) {
            userProgress[userId][subject] = {
                quizzes: [],
                readings: [],
                totalTime: 0
            };
        }

        userProgress[userId][subject][activity.type].push({
            activityId: activity.id,
            score,
            completedAt: new Date().toISOString()
        });

        res.json({ message: 'Progress updated successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Error updating progress' });
    }
});

// Get user progress
router.get('/progress/:userId/:subject', (req, res) => {
    try {
        const { userId, subject } = req.params;
        const progress = userProgress[userId]?.[subject] || {
            quizzes: [],
            readings: [],
            totalTime: 0
        };
        res.json(progress);
    } catch (error) {
        res.status(500).json({ error: 'Error fetching progress' });
    }
});

// Test endpoint
router.get('/test', (req, res) => {
    res.json({ message: 'Backend API is connected!' });
});

// Register user
router.post('/register',
    [
        body('email').isEmail(),
        body('password').isLength({ min: 6 }),
        body('name').not().isEmpty()
    ],
    async (req, res) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }

        try {
            const { name, email, password } = req.body;
            users.push({ name, email, password });
            res.json({ message: 'User registered successfully' });
        } catch (err) {
            res.status(500).send('Server error');
        }
    }
);

// Get courses
router.get('/courses', (req, res) => {
    try {
        const courses = [
            {
                id: 1,
                title: 'Mathematics Fundamentals',
                description: 'Basic to advanced mathematics',
                materials: educationalContent.mathematics
            },
            {
                id: 2,
                title: 'Science for Everyone',
                description: 'Interactive science lessons',
                materials: educationalContent.science
            },
            {
                id: 3,
                title: 'Language Learning',
                description: 'Master different languages',
                materials: educationalContent.languages
            }
        ];
        console.log('Sending courses data:', courses); // Debug log
        res.json(courses);
    } catch (error) {
        console.error('Error fetching courses:', error);
        res.status(500).json({ message: 'Error fetching courses' });
    }
});

// Upload PDF
router.post('/upload/:subject', upload.single('pdf'), async (req, res) => {
    try {
        const { subject } = req.params;
        const { title, description, topic } = req.body;

        if (!req.file) {
            return res.status(400).json({ error: 'No PDF file uploaded' });
        }

        console.log('Uploaded file:', req.file); // Debug log

        const pdf = new PDF({
            title,
            description,
            topic,
            subject,
            filename: req.file.filename,
            filepath: `/uploads/${req.file.filename}`
        });

        await pdf.save();
        console.log('Saved PDF to database:', pdf); // Debug log

        res.json({ 
            message: 'PDF uploaded successfully',
            pdf: {
                ...pdf.toObject(),
                url: `/api/pdf/${pdf.filename}`
            }
        });
    } catch (error) {
        console.error('Error uploading PDF:', error);
        res.status(500).json({ error: 'Error uploading PDF' });
    }
});

// Get PDFs for a subject
router.get('/pdfs/:subject', async (req, res) => {
    try {
        const { subject } = req.params;
        const pdfs = await PDF.find({ subject }).sort('-uploadDate');
        
        console.log('Found PDFs for subject:', subject, pdfs); // Debug log

        const pdfList = pdfs.map(pdf => ({
            ...pdf.toObject(),
            url: `/api/pdf/${pdf.filename}`
        }));

        res.json(pdfList);
    } catch (error) {
        console.error('Error fetching PDFs:', error);
        res.status(500).json({ error: 'Error fetching PDFs' });
    }
});

// Serve PDF file
router.get('/pdf/:filename', (req, res) => {
    try {
        const { filename } = req.params;
        const filepath = path.join(__dirname, '../../uploads', filename);
        
        console.log('Attempting to serve PDF:', filepath); // Debug log

        if (!fs.existsSync(filepath)) {
            console.error('PDF file not found:', filepath);
            return res.status(404).json({ error: 'PDF not found' });
        }

        // Set proper headers for PDF
        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', `inline; filename="${filename}"`);

        // Stream the file
        const fileStream = fs.createReadStream(filepath);
        fileStream.on('error', (error) => {
            console.error('Error streaming PDF:', error);
            res.status(500).json({ error: 'Error serving PDF' });
        });

        fileStream.pipe(res);
    } catch (error) {
        console.error('Error serving PDF:', error);
        res.status(500).json({ error: 'Error serving PDF' });
    }
});

// Update PDF metadata
router.put('/pdf/:subject/:id', (req, res) => {
    try {
        const { subject, id } = req.params;
        const { title, description, topic } = req.body;
        
        const pdf = pdfs[subject].find(pdf => pdf._id === id);
        if (!pdf) {
            return res.status(404).json({ error: 'PDF not found' });
        }

        // Update metadata
        pdf.title = title || pdf.title;
        pdf.description = description || pdf.description;
        pdf.topic = topic || pdf.topic;
        pdf.lastModified = new Date().toISOString();

        res.json({ message: 'PDF updated successfully', pdf });
    } catch (error) {
        res.status(500).json({ error: 'Error updating PDF' });
    }
});

// Search PDFs
router.get('/search/:subject', (req, res) => {
    try {
        const { subject } = req.params;
        const { query, topic } = req.query;
        
        let results = pdfs[subject];

        if (query) {
            const searchTerm = query.toLowerCase();
            results = results.filter(pdf => 
                pdf.title.toLowerCase().includes(searchTerm) ||
                (pdf.description && pdf.description.toLowerCase().includes(searchTerm))
            );
        }

        if (topic) {
            results = results.filter(pdf => pdf.topic === topic);
        }

        res.json(results);
    } catch (error) {
        res.status(500).json({ error: 'Error searching PDFs' });
    }
});

// Get notes by subject
router.get('/notes/:subject', (req, res) => {
    const subject = req.params.subject.toLowerCase();
    if (educationalContent[subject]) {
        res.json(educationalContent[subject].notes);
    } else {
        res.status(404).json({ message: 'Subject not found' });
    }
});

// Get speeches by subject
router.get('/speeches/:subject', (req, res) => {
    const subject = req.params.subject.toLowerCase();
    if (educationalContent[subject]) {
        res.json(educationalContent[subject].speeches);
    } else {
        res.status(404).json({ message: 'Subject not found' });
    }
});

// Get specific note
router.get('/note/:subject/:id', (req, res) => {
    const subject = req.params.subject.toLowerCase();
    const id = parseInt(req.params.id);
    
    if (educationalContent[subject]) {
        const note = educationalContent[subject].notes.find(n => n.id === id);
        if (note) {
            res.json(note);
        } else {
            res.status(404).json({ message: 'Note not found' });
        }
    } else {
        res.status(404).json({ message: 'Subject not found' });
    }
});

// Get specific speech
router.get('/speech/:subject/:id', (req, res) => {
    const subject = req.params.subject.toLowerCase();
    const id = parseInt(req.params.id);
    
    if (educationalContent[subject]) {
        const speech = educationalContent[subject].speeches.find(s => s.id === id);
        if (speech) {
            res.json(speech);
        } else {
            res.status(404).json({ message: 'Speech not found' });
        }
    } else {
        res.status(404).json({ message: 'Subject not found' });
    }
});

// Delete PDF
router.delete('/pdf/:id', async (req, res) => {
    try {
        const pdf = await PDF.findById(req.params.id);
        
        if (!pdf) {
            return res.status(404).json({ error: 'PDF not found' });
        }

        // Delete file from uploads directory
        const filePath = path.join(__dirname, '../..', pdf.filepath);
        if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
        }

        // Delete from database
        await pdf.deleteOne();

        res.json({ message: 'PDF deleted successfully' });
    } catch (error) {
        console.error('Error deleting PDF:', error);
        res.status(500).json({ error: 'Error deleting PDF' });
    }
});

module.exports = router;
