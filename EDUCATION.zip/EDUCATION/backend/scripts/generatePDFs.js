const pdf = require('html-pdf');
const fs = require('fs');
const path = require('path');

const options = {
    format: 'A4',
    border: {
        top: '20mm',
        right: '20mm',
        bottom: '20mm',
        left: '20mm'
    },
    footer: {
        height: '10mm',
        contents: {
            default: '<span style="color: #444; font-size: 10px;">{{page}}</span>/<span style="color: #444; font-size: 10px;">{{pages}}</span>'
        }
    }
};

const mathDir = path.join(__dirname, '..', 'public', 'pdfs', 'mathematics');

// Ensure directories exist
if (!fs.existsSync(mathDir)) {
    fs.mkdirSync(mathDir, { recursive: true });
}

// Convert HTML files to PDFs
const files = [
    {
        html: path.join(mathDir, 'algebra-basics.html'),
        pdf: path.join(mathDir, 'algebra-basics.pdf')
    },
    {
        html: path.join(mathDir, 'geometry-fundamentals.html'),
        pdf: path.join(mathDir, 'geometry-fundamentals.pdf')
    },
    {
        html: path.join(mathDir, 'calculus-intro.html'),
        pdf: path.join(mathDir, 'calculus-intro.pdf')
    }
];

files.forEach(file => {
    const html = fs.readFileSync(file.html, 'utf8');
    pdf.create(html, options).toFile(file.pdf, (err, res) => {
        if (err) {
            console.error(`Error creating ${file.pdf}:`, err);
        } else {
            console.log(`Successfully created ${file.pdf}`);
            // Remove HTML file after PDF is created
            fs.unlinkSync(file.html);
        }
    });
});
