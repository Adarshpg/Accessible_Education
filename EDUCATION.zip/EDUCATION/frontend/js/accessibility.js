// Accessibility Features
class AccessibilityManager {
    constructor() {
        this.speechSynthesis = window.speechSynthesis;
        this.isReading = false;
        this.currentUtterance = null;
        this.signLanguageEnabled = false;
        this.initializeAccessibility();
    }

    initializeAccessibility() {
        // Add accessibility controls
        const controls = document.createElement('div');
        controls.className = 'accessibility-controls';
        controls.innerHTML = `
            <button id="toggleAudio" class="access-btn" aria-label="Toggle Audio Assistant">
                <i class="fas fa-volume-up"></i>
            </button>
            <button id="toggleSign" class="access-btn" aria-label="Toggle Sign Language">
                <i class="fas fa-sign-language"></i>
            </button>
            <div class="voice-controls">
                <select id="voiceSelect" aria-label="Select Voice"></select>
                <input type="range" id="speechRate" min="0.5" max="2" step="0.1" value="1" 
                    aria-label="Speech Rate">
            </div>
        `;
        document.body.appendChild(controls);

        // Initialize voice selection
        this.populateVoiceList();
        speechSynthesis.addEventListener('voiceschanged', () => this.populateVoiceList());

        // Add event listeners
        document.getElementById('toggleAudio').addEventListener('click', () => this.toggleAudioAssistant());
        document.getElementById('toggleSign').addEventListener('click', () => this.toggleSignLanguage());
        document.getElementById('speechRate').addEventListener('change', (e) => this.updateSpeechRate(e.target.value));
    }

    populateVoiceList() {
        const voiceSelect = document.getElementById('voiceSelect');
        voiceSelect.innerHTML = '';
        
        const voices = this.speechSynthesis.getVoices();
        voices.forEach((voice, i) => {
            const option = document.createElement('option');
            option.value = i;
            option.textContent = `${voice.name} (${voice.lang})`;
            voiceSelect.appendChild(option);
        });
    }

    speak(text) {
        if (this.isReading) {
            this.speechSynthesis.cancel();
        }

        const utterance = new SpeechSynthesisUtterance(text);
        const voices = this.speechSynthesis.getVoices();
        const selectedVoice = document.getElementById('voiceSelect').value;
        const rate = document.getElementById('speechRate').value;

        utterance.voice = voices[selectedVoice];
        utterance.rate = parseFloat(rate);
        utterance.onend = () => {
            this.isReading = false;
            this.currentUtterance = null;
        };

        this.currentUtterance = utterance;
        this.isReading = true;
        this.speechSynthesis.speak(utterance);
    }

    stopSpeaking() {
        if (this.isReading) {
            this.speechSynthesis.cancel();
            this.isReading = false;
            this.currentUtterance = null;
        }
    }

    toggleAudioAssistant() {
        const button = document.getElementById('toggleAudio');
        button.classList.toggle('active');
        
        if (button.classList.contains('active')) {
            this.enableAudioAssistant();
        } else {
            this.disableAudioAssistant();
        }
    }

    enableAudioAssistant() {
        // Add hover listeners to all readable elements
        document.querySelectorAll('.readable').forEach(element => {
            element.addEventListener('mouseenter', () => {
                const text = element.getAttribute('aria-label') || element.textContent;
                this.speak(text);
            });
            element.addEventListener('mouseleave', () => this.stopSpeaking());
        });
    }

    disableAudioAssistant() {
        this.stopSpeaking();
        // Remove hover listeners
        document.querySelectorAll('.readable').forEach(element => {
            element.removeEventListener('mouseenter', () => {});
            element.removeEventListener('mouseleave', () => {});
        });
    }

    toggleSignLanguage() {
        const button = document.getElementById('toggleSign');
        button.classList.toggle('active');
        this.signLanguageEnabled = button.classList.contains('active');
        
        if (this.signLanguageEnabled) {
            this.enableSignLanguage();
        } else {
            this.disableSignLanguage();
        }
    }

    enableSignLanguage() {
        // Add sign language avatar container if not exists
        if (!document.getElementById('signLanguageAvatar')) {
            const avatarContainer = document.createElement('div');
            avatarContainer.id = 'signLanguageAvatar';
            avatarContainer.className = 'sign-language-avatar';
            document.body.appendChild(avatarContainer);
        }

        // Make avatar visible
        document.getElementById('signLanguageAvatar').style.display = 'block';
        
        // Add sign language translations to readable elements
        document.querySelectorAll('.readable').forEach(element => {
            element.addEventListener('click', () => {
                const text = element.getAttribute('aria-label') || element.textContent;
                this.showSignLanguage(text);
            });
        });
    }

    disableSignLanguage() {
        const avatar = document.getElementById('signLanguageAvatar');
        if (avatar) {
            avatar.style.display = 'none';
        }
    }

    async showSignLanguage(text) {
        const avatar = document.getElementById('signLanguageAvatar');
        if (!avatar || !this.signLanguageEnabled) return;

        try {
            // Here you would integrate with a sign language avatar API
            // For demonstration, we'll show a placeholder animation
            avatar.innerHTML = `
                <div class="avatar-container">
                    <div class="avatar-animation">
                        <i class="fas fa-sign-language fa-3x"></i>
                    </div>
                    <p class="avatar-text">${text}</p>
                </div>
            `;
        } catch (error) {
            console.error('Error showing sign language:', error);
        }
    }

    // Add this method to make elements readable
    makeReadable(element, label) {
        element.classList.add('readable');
        if (label) {
            element.setAttribute('aria-label', label);
        }
    }
}

// Initialize accessibility features
const accessibilityManager = new AccessibilityManager();

// Export for use in other files
window.accessibilityManager = accessibilityManager;
