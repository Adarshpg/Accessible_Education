document.addEventListener('DOMContentLoaded', function() {
    // API Base URL - using the same port as backend since we're serving frontend from there
    const API_BASE_URL = 'http://localhost:3002/api';

    // Accessibility Features
    const accessibilityBtn = document.querySelector('.accessibility-btn');
    let isHighContrast = false;
    let isLargeText = false;

    // High Contrast Toggle
    function toggleHighContrast() {
        isHighContrast = !isHighContrast;
        document.body.classList.toggle('high-contrast');
    }

    // Large Text Toggle
    function toggleLargeText() {
        isLargeText = !isLargeText;
        document.body.classList.toggle('large-text');
    }

    // Text-to-Speech
    function speak(text) {
        if ('speechSynthesis' in window) {
            const utterance = new SpeechSynthesisUtterance(text);
            utterance.lang = document.getElementById('language-select').value;
            window.speechSynthesis.speak(utterance);
        }
    }

    // Language Switcher
    const languageSelect = document.getElementById('language-select');
    languageSelect.addEventListener('change', function() {
        translateContent(this.value);
    });

    // Fetch and display courses
    async function fetchCourses() {
        try {
            const response = await fetch(`${API_BASE_URL}/courses`);
            const courses = await response.json();
            renderCourses(courses);
        } catch (error) {
            console.error('Error fetching courses:', error);
            showError('Failed to load courses. Please try again later.');
        }
    }

    // Open Notes Modal
    async function openNotes(subject) {
        try {
            const response = await fetch(`${API_BASE_URL}/notes/${subject}`);
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const notes = await response.json();
            
            // Create modal container
            const modal = document.createElement('div');
            modal.className = 'modal';
            modal.innerHTML = `
                <div class="modal-content">
                    <div class="modal-header">
                        <h2>${subject.charAt(0).toUpperCase() + subject.slice(1)} Notes</h2>
                        <button class="close-btn" onclick="closeModal(this)">×</button>
                    </div>
                    <div class="modal-body">
                        ${notes.map(note => `
                            <div class="note-card">
                                <h3>${note.title}</h3>
                                <div class="note-content">
                                    <p>${note.content}</p>
                                </div>
                                <div class="note-controls">
                                    <button onclick="speak('${note.transcription}')" class="control-btn">
                                        <i class="fas fa-volume-up"></i> Listen
                                    </button>
                                    <a href="${note.signLanguageUrl}" target="_blank" class="control-btn">
                                        <i class="fas fa-american-sign-language-interpreting"></i> Sign Language
                                    </a>
                                    <button onclick="speak('${note.content}')" class="control-btn">
                                        <i class="fas fa-book-reader"></i> Read Content
                                    </button>
                                    ${note.pdfUrl ? `
                                        <button onclick="openPDF('${note.pdfUrl}', '${note.pdfTitle}')" class="control-btn pdf-btn">
                                            <i class="fas fa-file-pdf"></i> View PDF
                                        </button>
                                    ` : ''}
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            `;
            document.body.appendChild(modal);
            
            // Add event listener to close modal when clicking outside
            modal.addEventListener('click', function(e) {
                if (e.target === modal) {
                    closeModal(modal);
                }
            });
        } catch (error) {
            console.error('Error fetching notes:', error);
            showError(`Failed to load ${subject} notes. Please try again later.`);
        }
    }

    // Open PDF in a new modal
    function openPDF(pdfUrl, title) {
        const pdfModal = document.createElement('div');
        pdfModal.className = 'modal pdf-modal';
        pdfModal.innerHTML = `
            <div class="modal-content pdf-content">
                <div class="modal-header">
                    <h2>${title}</h2>
                    <div class="pdf-controls">
                        <a href="${pdfUrl}" download class="control-btn">
                            <i class="fas fa-download"></i> Download PDF
                        </a>
                        <button class="close-btn" onclick="closeModal(this)">×</button>
                    </div>
                </div>
                <div class="modal-body pdf-container">
                    <iframe src="${pdfUrl}" type="application/pdf" width="100%" height="100%">
                        <p>Your browser doesn't support embedded PDFs. 
                           <a href="${pdfUrl}" target="_blank">Click here to download the PDF</a>
                        </p>
                    </iframe>
                </div>
            </div>
        `;
        document.body.appendChild(pdfModal);

        // Add event listener to close modal when clicking outside
        pdfModal.addEventListener('click', function(e) {
            if (e.target === pdfModal) {
                closeModal(pdfModal);
            }
        });
    }

    // Close Modal
    window.closeModal = function(button) {
        const modal = button.closest('.modal');
        modal.remove();
    };

    // Render Courses with PDF Upload
    function renderCourses(courses) {
        const courseContainer = document.getElementById('course-container');
        courseContainer.innerHTML = '';

        courses.forEach(course => {
            const subject = course.title.toLowerCase().split(' ')[0];
            const courseElement = document.createElement('div');
            courseElement.className = 'feature-card';
            courseElement.innerHTML = `
                <h3>${course.title}</h3>
                <p>${course.description}</p>
                <div class="course-actions">
                    <button onclick="speak('${course.title}: ${course.description}')" 
                            class="action-btn" aria-label="Listen to course description">
                        <i class="fas fa-volume-up"></i> Listen
                    </button>
                    <button onclick="openNotes('${subject}')"
                            class="action-btn" aria-label="View course notes">
                        <i class="fas fa-book"></i> Notes
                    </button>
                    <button onclick="displayCoursePDFs('${subject}')" class="action-btn" aria-label="View course PDFs">
                        <i class="fas fa-file-pdf"></i> Course PDFs
                    </button>
                    <button onclick="showQuizzes('${subject}')"
                            class="action-btn" aria-label="View quizzes">
                        <i class="fas fa-question-circle"></i> Quizzes
                    </button>
                    <button onclick="showDiscussions('${subject}')"
                            class="action-btn" aria-label="View discussions">
                        <i class="fas fa-comments"></i> Discussions
                    </button>
                    <button onclick="showProgress('${subject}')"
                            class="action-btn" aria-label="View progress">
                        <i class="fas fa-chart-line"></i> Progress
                    </button>
                </div>
            `;
            courseContainer.appendChild(courseElement);
        });
    }

    let currentSubject = null;

    async function displayCoursePDFs(subject) {
        currentSubject = subject;
        const pdfContainer = document.getElementById('pdfContainer');
        pdfContainer.innerHTML = '<p class="loading">Loading PDFs...</p>';

        try {
            const response = await fetch(`${API_BASE_URL}/pdfs/${subject}`);
            if (!response.ok) throw new Error('Failed to fetch PDFs');
            
            const pdfs = await response.json();
            
            if (pdfs.length === 0) {
                pdfContainer.innerHTML = '<p>No PDFs available for this subject.</p>';
                return;
            }

            pdfContainer.innerHTML = '';
            pdfs.forEach(pdf => {
                const card = document.createElement('div');
                card.className = 'pdf-card';
                card.innerHTML = `
                    <div class="pdf-info">
                        <h3>${pdf.title}</h3>
                        <p>${pdf.description || 'No description available'}</p>
                        <p class="pdf-meta">Topic: ${pdf.topic || 'General'}</p>
                    </div>
                    <div class="pdf-actions">
                        <button onclick="viewPDF('/api/pdf/${encodeURIComponent(pdf.filename)}')" class="action-btn">
                            <i class="fas fa-eye"></i> View
                        </button>
                        <a href="/api/pdf/${encodeURIComponent(pdf.filename)}" download class="action-btn">
                            <i class="fas fa-download"></i> Download
                        </a>
                        <button onclick="deletePDF('${pdf._id}')" class="action-btn delete">
                            <i class="fas fa-trash"></i> Delete
                        </button>
                    </div>
                `;
                pdfContainer.appendChild(card);
            });
        } catch (error) {
            console.error('Error fetching PDFs:', error);
            pdfContainer.innerHTML = '<p class="error">Error loading PDFs. Please try again.</p>';
        }
    }

    function viewPDF(url) {
        console.log('Opening PDF URL:', url); // Debug log
        
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.innerHTML = `
            <div class="modal-content pdf-viewer-modal">
                <div class="modal-header">
                    <h2>PDF Viewer</h2>
                    <button class="close-btn" onclick="closeModal(this)">×</button>
                </div>
                <div class="modal-body">
                    <div class="pdf-container">
                        <iframe
                            src="${url}"
                            frameborder="0"
                            width="100%"
                            height="100%"
                            class="pdf-viewer"
                        ></iframe>
                        <div class="pdf-fallback" style="display: none;">
                            <p>Unable to display PDF directly. Please choose an option:</p>
                            <div class="pdf-actions">
                                <a href="${url}" target="_blank" class="action-btn">Open in New Tab</a>
                                <a href="${url}" download class="action-btn">Download PDF</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;

        document.body.appendChild(modal);

        const iframe = modal.querySelector('iframe');
        iframe.onerror = () => {
            console.error('Error loading PDF in iframe'); // Debug log
            iframe.style.display = 'none';
            modal.querySelector('.pdf-fallback').style.display = 'block';
        };
    }

    // Show Upload Modal
    async function showUploadModal(subject) {
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h2>Upload PDF</h2>
                    <button class="close-btn" onclick="closeModal(this)">×</button>
                </div>
                <div class="modal-body">
                    <form id="uploadForm">
                        <div class="form-group">
                            <label for="title">Title:</label>
                            <input type="text" id="title" required>
                        </div>
                        <div class="form-group">
                            <label for="description">Description:</label>
                            <textarea id="description"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="topic">Topic:</label>
                            <select id="topic">
                                <option value="basics">Basics</option>
                                <option value="advanced">Advanced</option>
                                <option value="practice">Practice</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="pdf">PDF File:</label>
                            <input type="file" id="pdf" accept=".pdf" required>
                        </div>
                        <button type="submit" class="action-btn">Upload</button>
                    </form>
                </div>
            </div>
        `;
        document.body.appendChild(modal);

        const form = modal.querySelector('#uploadForm');
        form.onsubmit = async (e) => {
            e.preventDefault();
            
            const formData = new FormData();
            formData.append('title', form.title.value);
            formData.append('description', form.description.value);
            formData.append('topic', form.topic.value);
            formData.append('pdf', form.pdf.files[0]);

            try {
                const response = await fetch(`${API_BASE_URL}/upload/${subject}`, {
                    method: 'POST',
                    body: formData
                });

                const result = await response.json();
                
                if (!response.ok) {
                    throw new Error(result.error || 'Upload failed');
                }

                // Show success message
                alert('PDF uploaded successfully!');
                
                // Close the modal and refresh PDFs
                closeModal(modal);
                displayCoursePDFs(subject);
            } catch (error) {
                console.error('Error uploading PDF:', error);
                alert('Error uploading PDF: ' + error.message);
            }
        };
    }

    // View PDFs
    async function viewPDFs(subject) {
        const container = document.getElementById('content');
        container.innerHTML = `
            <div class="education-section">
                <div class="section-header">
                    <h2>${subject.charAt(0).toUpperCase() + subject.slice(1)} PDFs</h2>
                    <button onclick="showUploadModal('${subject}')" 
                            class="action-btn upload-btn" aria-label="Upload PDF">
                        <i class="fas fa-upload"></i> Upload PDF
                    </button>
                </div>
                <div id="pdfGrid" class="pdf-grid">
                    <div class="loading">Loading PDFs...</div>
                </div>
            </div>
        `;

        try {
            const response = await fetch(`${API_BASE_URL}/pdfs/${subject}`);
            const pdfs = await response.json();
            
            const pdfGrid = document.getElementById('pdfGrid');
            pdfGrid.innerHTML = ''; // Clear loading message

            if (pdfs.length === 0) {
                pdfGrid.innerHTML = '<div class="no-pdfs">No PDFs available for this subject. Upload some!</div>';
                return;
            }

            pdfs.forEach(pdf => {
                const pdfCard = document.createElement('div');
                pdfCard.className = 'pdf-card';
                pdfCard.innerHTML = `
                    <div class="pdf-info">
                        <h3>${pdf.title}</h3>
                        <p>${pdf.description || 'No description available'}</p>
                        <p class="pdf-meta">Topic: ${pdf.topic || 'General'}</p>
                    </div>
                    <div class="pdf-actions">
                        <button onclick="viewPDF('/api/pdf/${encodeURIComponent(pdf.filename)}')" class="action-btn view-btn">
                            <i class="fas fa-eye"></i> View
                        </button>
                        <a href="/api/pdf/${encodeURIComponent(pdf.filename)}" download class="action-btn download-btn">
                            <i class="fas fa-download"></i> Download
                        </a>
                        <button onclick="deletePDF('${subject}', '${pdf._id}')" class="action-btn delete-btn">
                            <i class="fas fa-trash"></i> Delete
                        </button>
                    </div>
                `;
                pdfGrid.appendChild(pdfCard);
            });
        } catch (error) {
            console.error('Error fetching PDFs:', error);
            const pdfGrid = document.getElementById('pdfGrid');
            pdfGrid.innerHTML = '<div class="error-message">Error loading PDFs. Please try again.</div>';
        }
    }

    async function deletePDF(subject, pdfId) {
        if (!confirm('Are you sure you want to delete this PDF?')) {
            return;
        }

        try {
            const response = await fetch(`${API_BASE_URL}/pdf/${subject}/${pdfId}`, {
                method: 'DELETE'
            });

            if (!response.ok) {
                throw new Error('Failed to delete PDF');
            }

            // Refresh the PDF list
            viewPDFs(subject);
        } catch (error) {
            console.error('Error deleting PDF:', error);
            alert('Error deleting PDF. Please try again.');
        }
    }

    // Search PDFs
    async function searchPDFs(subject) {
        const searchTerm = document.getElementById('searchPDF').value;
        const topic = document.getElementById('topicFilter').value;
        
        try {
            const response = await fetch(`${API_BASE_URL}/search/${subject}?query=${searchTerm}&topic=${topic}`);
            const pdfs = await response.json();
            
            const pdfList = document.getElementById('pdfList');
            pdfList.innerHTML = '';

            pdfs.forEach(pdf => {
                const pdfCard = document.createElement('div');
                pdfCard.className = 'pdf-card';
                pdfCard.setAttribute('role', 'listitem');
                pdfCard.innerHTML = `
                    <div class="pdf-info">
                        <h3>${pdf.title}</h3>
                        ${pdf.description ? `<p>${pdf.description}</p>` : ''}
                        ${pdf.topic ? `<span class="topic-tag">${pdf.topic}</span>` : ''}
                        <p class="upload-date">Uploaded: ${new Date(pdf.uploadDate).toLocaleDateString()}</p>
                    </div>
                    <div class="pdf-actions">
                        <button onclick="viewPDF('/api/pdf/${encodeURIComponent(pdf.filename)}')" class="action-btn"
                            aria-label="View ${pdf.title}">
                            <i class="fas fa-eye"></i> View
                        </button>
                        <button onclick="editPDF('${subject}', ${pdf.id})" class="action-btn"
                            aria-label="Edit ${pdf.title}">
                            <i class="fas fa-edit"></i> Edit
                        </button>
                        <button onclick="deletePDF('${subject}', ${pdf.id})" class="action-btn delete"
                            aria-label="Delete ${pdf.title}">
                            <i class="fas fa-trash"></i> Delete
                        </button>
                    </div>
                `;
                pdfList.appendChild(pdfCard);
            });

            // Make new elements readable
            makeElementsReadable();
        } catch (error) {
            console.error('Error fetching PDFs:', error);
        }
    }

    // Edit PDF Metadata
    async function editPDF(subject, id) {
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h2>Edit PDF Details</h2>
                    <button class="close-btn" onclick="closeModal(this)">×</button>
                </div>
                <div class="modal-body">
                    <form id="pdfEditForm">
                        <div class="form-group">
                            <label for="editTitle">Title:</label>
                            <input type="text" id="editTitle" name="title" required>
                        </div>
                        <div class="form-group">
                            <label for="editDescription">Description:</label>
                            <textarea id="editDescription" name="description"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="editTopic">Topic:</label>
                            <select id="editTopic" name="topic">
                                <option value="basics">Basics</option>
                                <option value="advanced">Advanced</option>
                                <option value="practice">Practice</option>
                            </select>
                        </div>
                        <button type="submit" class="action-btn">Save Changes</button>
                    </form>
                </div>
            </div>
        `;
        document.body.appendChild(modal);

        const form = modal.querySelector('#pdfEditForm');
        form.onsubmit = async (e) => {
            e.preventDefault();
            try {
                const response = await fetch(`${API_BASE_URL}/pdf/${subject}/${id}`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        title: form.title.value,
                        description: form.description.value,
                        topic: form.topic.value
                    })
                });

                if (!response.ok) throw new Error('Failed to update PDF');
                
                closeModal(modal);
                searchPDFs(subject); // Refresh the list
            } catch (error) {
                console.error('Error updating PDF:', error);
                alert('Error updating PDF: ' + error.message);
            }
        };
    }

    // Quiz Functions
    async function showQuizzes(subject) {
        const container = document.getElementById('content');
        container.innerHTML = `
            <div class="education-section">
                <div class="section-header">
                    <h2>${subject.charAt(0).toUpperCase() + subject.slice(1)} Quizzes</h2>
                    <button class="action-btn" onclick="createQuiz('${subject}')">
                        <i class="fas fa-plus"></i> Create Quiz
                    </button>
                </div>
                <div class="quiz-grid" id="quizList"></div>
            </div>
        `;

        try {
            const response = await fetch(`${API_BASE_URL}/quiz/${subject}`);
            const quizzes = await response.json();

            const quizList = document.getElementById('quizList');
            quizzes.forEach(quiz => {
                const quizCard = document.createElement('div');
                quizCard.className = 'quiz-card';
                quizCard.innerHTML = `
                    <div class="quiz-info">
                        <h3>${quiz.title}</h3>
                        <p>${quiz.questions.length} Questions | ${quiz.timeLimit} Minutes</p>
                        <p class="quiz-stats">
                            Attempts: ${quiz.attempts.length} | 
                            Avg Score: ${calculateAverageScore(quiz.attempts)}%
                        </p>
                    </div>
                    <div class="quiz-actions">
                        <button onclick="startQuiz('${subject}', ${quiz.id})" class="action-btn">
                            <i class="fas fa-play"></i> Start Quiz
                        </button>
                    </div>
                `;
                quizList.appendChild(quizCard);
            });
        } catch (error) {
            console.error('Error loading quizzes:', error);
        }
    }

    function calculateAverageScore(attempts) {
        if (!attempts.length) return 0;
        const total = attempts.reduce((sum, attempt) => sum + attempt.score, 0);
        return Math.round((total / attempts.length) * 100);
    }

    async function createQuiz(subject) {
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h2>Create New Quiz</h2>
                    <button class="close-btn" onclick="closeModal(this)">×</button>
                </div>
                <div class="modal-body">
                    <form id="quizForm">
                        <div class="form-group">
                            <label for="quizTitle">Quiz Title:</label>
                            <input type="text" id="quizTitle" required>
                        </div>
                        <div class="form-group">
                            <label for="timeLimit">Time Limit (minutes):</label>
                            <input type="number" id="timeLimit" min="1" value="30" required>
                        </div>
                        <div id="questions">
                            <!-- Questions will be added here -->
                        </div>
                        <button type="button" onclick="addQuestion()" class="action-btn">
                            <i class="fas fa-plus"></i> Add Question
                        </button>
                        <button type="submit" class="action-btn">Create Quiz</button>
                    </form>
                </div>
            </div>
        `;
        document.body.appendChild(modal);

        // Add first question by default
        addQuestion();

        const form = modal.querySelector('#quizForm');
        form.onsubmit = async (e) => {
            e.preventDefault();
            const questions = [];
            document.querySelectorAll('.question-item').forEach(item => {
                questions.push({
                    question: item.querySelector('.question-text').value,
                    options: Array.from(item.querySelectorAll('.option-text')).map(opt => opt.value),
                    correctAnswer: parseInt(item.querySelector('.correct-answer').value)
                });
            });

            try {
                const response = await fetch(`${API_BASE_URL}/quiz/${subject}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        title: form.quizTitle.value,
                        timeLimit: parseInt(form.timeLimit.value),
                        questions
                    })
                });

                const result = await response.json();
                
                if (!response.ok) {
                    throw new Error(result.error || 'Upload failed');
                }

                // Show success message
                alert('Quiz created successfully!');
                
                // Close the modal and refresh quizzes
                closeModal(modal);
                showQuizzes(subject);
            } catch (error) {
                console.error('Error creating quiz:', error);
                alert('Error creating quiz: ' + error.message);
            }
        };
    }

    function addQuestion() {
        const questions = document.getElementById('questions');
        const questionNumber = questions.children.length + 1;
        
        const questionDiv = document.createElement('div');
        questionDiv.className = 'question-item';
        questionDiv.innerHTML = `
            <h3>Question ${questionNumber}</h3>
            <div class="form-group">
                <label>Question Text:</label>
                <textarea class="question-text" required></textarea>
            </div>
            <div class="options-group">
                <label>Options:</label>
                <div class="option">
                    <input type="text" class="option-text" placeholder="Option 1" required>
                </div>
                <div class="option">
                    <input type="text" class="option-text" placeholder="Option 2" required>
                </div>
                <div class="option">
                    <input type="text" class="option-text" placeholder="Option 3" required>
                </div>
                <div class="option">
                    <input type="text" class="option-text" placeholder="Option 4" required>
                </div>
            </div>
            <div class="form-group">
                <label>Correct Answer (1-4):</label>
                <input type="number" class="correct-answer" min="1" max="4" required>
            </div>
        `;
        questions.appendChild(questionDiv);
    }

    // Discussion Forum Functions
    async function showDiscussions(subject) {
        const container = document.getElementById('content');
        container.innerHTML = `
            <div class="education-section">
                <div class="section-header">
                    <h2>${subject.charAt(0).toUpperCase() + subject.slice(1)} Discussions</h2>
                    <button class="action-btn" onclick="createDiscussion('${subject}')">
                        <i class="fas fa-plus"></i> New Discussion
                    </button>
                </div>
                <div class="discussion-list" id="discussionList"></div>
            </div>
        `;

        try {
            const response = await fetch(`${API_BASE_URL}/discussion/${subject}`);
            const discussions = await response.json();

            const discussionList = document.getElementById('discussionList');
            discussions.forEach(discussion => {
                const discussionCard = document.createElement('div');
                discussionCard.className = 'discussion-card';
                discussionCard.innerHTML = `
                    <div class="discussion-header">
                        <h3>${discussion.title}</h3>
                        <span class="discussion-meta">
                            Posted by ${discussion.userName} | 
                            ${new Date(discussion.createdAt).toLocaleDateString()}
                        </span>
                    </div>
                    <div class="discussion-content">${discussion.content}</div>
                    <div class="discussion-stats">
                        <span>${discussion.replies.length} replies</span>
                        <span>${discussion.likes} likes</span>
                    </div>
                    <div class="discussion-actions">
                        <button onclick="viewDiscussion('${subject}', ${discussion.id})" class="action-btn">
                            <i class="fas fa-comments"></i> View Discussion
                        </button>
                    </div>
                `;
                discussionList.appendChild(discussionCard);
            });
        } catch (error) {
            console.error('Error loading discussions:', error);
        }
    }

    // Progress Tracking Functions
    async function showProgress(subject) {
        const userId = '123'; // Replace with actual user ID
        try {
            const response = await fetch(`${API_BASE_URL}/progress/${userId}/${subject}`);
            const progress = await response.json();

            const container = document.getElementById('content');
            container.innerHTML = `
                <div class="education-section">
                    <div class="section-header">
                        <h2>${subject.charAt(0).toUpperCase() + subject.slice(1)} Progress</h2>
                    </div>
                    <div class="progress-dashboard">
                        <div class="progress-card">
                            <h3>Quiz Performance</h3>
                            <div class="progress-stats">
                                <div class="stat-item">
                                    <span class="stat-label">Quizzes Completed</span>
                                    <span class="stat-value">${progress.quizzes.length}</span>
                                </div>
                                <div class="stat-item">
                                    <span class="stat-label">Average Score</span>
                                    <span class="stat-value">${calculateAverageScore(progress.quizzes)}%</span>
                                </div>
                            </div>
                        </div>
                        <div class="progress-card">
                            <h3>Reading Progress</h3>
                            <div class="progress-stats">
                                <div class="stat-item">
                                    <span class="stat-label">Materials Read</span>
                                    <span class="stat-value">${progress.readings.length}</span>
                                </div>
                                <div class="stat-item">
                                    <span class="stat-label">Total Time</span>
                                    <span class="stat-value">${Math.round(progress.totalTime / 60)} mins</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="progress-history">
                        <h3>Recent Activity</h3>
                        <div class="activity-timeline">
                            ${generateActivityTimeline(progress)}
                        </div>
                    </div>
                </div>
            `;
        } catch (error) {
            console.error('Error loading progress:', error);
        }
    }

    function generateActivityTimeline(progress) {
        const activities = [
            ...progress.quizzes.map(q => ({
                type: 'quiz',
                date: new Date(q.completedAt),
                score: q.score
            })),
            ...progress.readings.map(r => ({
                type: 'reading',
                date: new Date(r.completedAt)
            }))
        ].sort((a, b) => b.date - a.date);

        return activities.map(activity => `
            <div class="activity-item">
                <i class="fas fa-${activity.type === 'quiz' ? 'question-circle' : 'book-reader'}"></i>
                <div class="activity-details">
                    <span class="activity-type">
                        ${activity.type === 'quiz' ? 'Completed Quiz' : 'Read Material'}
                    </span>
                    <span class="activity-date">
                        ${activity.date.toLocaleDateString()}
                    </span>
                    ${activity.score ? `<span class="activity-score">Score: ${activity.score}%</span>` : ''}
                </div>
            </div>
        `).join('');
    }

    // Make elements readable after they're added to the DOM
    function makeElementsReadable() {
        // Make PDF cards readable
        document.querySelectorAll('.pdf-card').forEach(card => {
            const title = card.querySelector('h3').textContent;
            const description = card.querySelector('p')?.textContent || '';
            const label = `PDF: ${title}. ${description}`;
            accessibilityManager.makeReadable(card, label);
        });

        // Make buttons readable
        document.querySelectorAll('.action-btn').forEach(button => {
            const label = button.textContent.trim();
            accessibilityManager.makeReadable(button, label);
        });

        // Make form inputs readable
        document.querySelectorAll('input, select, textarea').forEach(input => {
            const label = input.getAttribute('placeholder') || input.getAttribute('aria-label');
            if (label) {
                accessibilityManager.makeReadable(input, label);
            }
        });
    }

    // Make functions globally available
    window.speak = speak;
    window.openNotes = openNotes;
    window.openPDF = openPDF;
    window.closeModal = closeModal;
    window.showUploadModal = showUploadModal;
    window.viewPDFs = viewPDFs;
    window.showQuizzes = showQuizzes;
    window.showDiscussions = showDiscussions;
    window.showProgress = showProgress;

    async function displaySubjects() {
        const subjects = [
            { name: 'Mathematics', type: 'math' },
            { name: 'Physics', type: 'science' },
            { name: 'Chemistry', type: 'science' },
            { name: 'Computer Science', type: 'science' },
            { name: 'Language Learning', type: 'language' }
        ];

        const subjectsContainer = document.getElementById('subjectsContainer');
        subjectsContainer.innerHTML = subjects.map(subject => {
            let buttons = '';
            
            if (subject.type === 'math') {
                // Mathematics only shows PDF functionality
                buttons = `
                    <button onclick="displayCoursePDFs('${subject.name}')" class="action-btn" aria-label="View course PDFs">
                        <i class="fas fa-file-pdf"></i> Course PDFs
                    </button>
                    <button onclick="showUploadModal('${subject.name}')" class="action-btn upload-btn" aria-label="Upload PDF">
                        <i class="fas fa-upload"></i> Upload PDF
                    </button>
                `;
            } else if (subject.type === 'science') {
                // Science subjects show only PDFs
                buttons = `
                    <button onclick="displayCoursePDFs('${subject.name}')" class="action-btn" aria-label="View course PDFs">
                        <i class="fas fa-file-pdf"></i> Course PDFs
                    </button>
                    <button onclick="showUploadModal('${subject.name}')" class="action-btn upload-btn" aria-label="Upload PDF">
                        <i class="fas fa-upload"></i> Upload PDF
                    </button>
                `;
            } else if (subject.type === 'language') {
                // Language learning has specific features
                buttons = `
                    <button onclick="showLanguageLessons('${subject.name}')" class="action-btn" aria-label="View language lessons">
                        <i class="fas fa-book"></i> Lessons
                    </button>
                    <button onclick="showPracticeExercises('${subject.name}')" class="action-btn" aria-label="Practice exercises">
                        <i class="fas fa-tasks"></i> Practice
                    </button>
                    <button onclick="showVocabulary('${subject.name}')" class="action-btn" aria-label="View vocabulary">
                        <i class="fas fa-list"></i> Vocabulary
                    </button>
                `;
            }

            return `
                <div class="subject-card">
                    <h2>${subject.name}</h2>
                    <div class="subject-actions">
                        ${buttons}
                    </div>
                </div>
            `;
        }).join('');
    }

    // Language learning functions
    function showLanguageLessons(subject) {
        alert('Language lessons feature coming soon!');
    }

    function showPracticeExercises(subject) {
        alert('Practice exercises feature coming soon!');
    }

    function showVocabulary(subject) {
        alert('Vocabulary feature coming soon!');
    }

    // Initialize
    fetchCourses();
    displaySubjects();
});

// Global variables
let currentSubject = null;

// Show/Hide sections
function showUploadSection() {
    document.getElementById('uploadSection').style.display = 'block';
    document.getElementById('coursesSection').style.display = 'none';
    setActiveNav('Upload PDF');
}

function showAvailableCourses() {
    document.getElementById('uploadSection').style.display = 'none';
    document.getElementById('coursesSection').style.display = 'block';
    setActiveNav('Available Courses');
    if (currentSubject) {
        showCoursePDFs(currentSubject);
    }
}

function setActiveNav(section) {
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.classList.toggle('active', btn.textContent === section);
    });
}

// Handle PDF Upload
document.getElementById('uploadForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const subject = formData.get('subject');
    
    try {
        const response = await fetch(`/api/upload/${subject}`, {
            method: 'POST',
            body: formData
        });

        if (!response.ok) throw new Error('Upload failed');

        const result = await response.json();
        alert('PDF uploaded successfully!');
        showAvailableCourses();
        showCoursePDFs(subject);
        e.target.reset();
    } catch (error) {
        console.error('Error uploading PDF:', error);
        alert('Failed to upload PDF. Please try again.');
    }
});

// Show Course PDFs
async function showCoursePDFs(subject) {
    currentSubject = subject;
    const pdfList = document.getElementById('pdfList');
    const selectedSubject = document.getElementById('selectedSubject');
    
    selectedSubject.textContent = `${subject} PDFs`;
    pdfList.innerHTML = '<p class="loading">Loading PDFs...</p>';

    try {
        const response = await fetch(`/api/pdfs/${subject}`);
        if (!response.ok) throw new Error('Failed to fetch PDFs');
        
        const pdfs = await response.json();
        
        if (pdfs.length === 0) {
            pdfList.innerHTML = '<p class="no-pdfs">No PDFs available for this subject</p>';
            return;
        }

        pdfList.innerHTML = pdfs.map(pdf => `
            <div class="pdf-card">
                <div class="pdf-info">
                    <h3>${pdf.title}</h3>
                    <p>${pdf.description || 'No description available'}</p>
                    <p class="topic">Topic: ${pdf.topic}</p>
                </div>
                <div class="pdf-actions">
                    <button onclick="viewPDF('${pdf.url}')" class="action-btn">
                        <i class="fas fa-eye"></i> View
                    </button>
                    <a href="${pdf.url}" download class="action-btn">
                        <i class="fas fa-download"></i> Download
                    </a>
                </div>
            </div>
        `).join('');
    } catch (error) {
        console.error('Error fetching PDFs:', error);
        pdfList.innerHTML = '<p class="error">Error loading PDFs. Please try again.</p>';
    }
}

// PDF Viewer
function viewPDF(url) {
    const modal = document.getElementById('pdfViewerModal');
    const viewer = document.getElementById('pdfViewer');
    const downloadBtn = document.getElementById('downloadBtn');
    const openTabBtn = document.getElementById('openTabBtn');

    viewer.src = url;
    modal.style.display = 'block';

    downloadBtn.onclick = () => {
        window.location.href = url + '?download=true';
    };

    openTabBtn.onclick = () => {
        window.open(url, '_blank');
    };
}

// Close Modal
function closeModal() {
    const modal = document.getElementById('pdfViewerModal');
    modal.style.display = 'none';
    document.getElementById('pdfViewer').src = '';
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    showAvailableCourses();
});
